-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 07, 2023 at 07:30 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `internetbanking`
--

-- --------------------------------------------------------

--
-- Table structure for table `ib_acc_types`
--

CREATE TABLE `ib_acc_types` (
  `acctype_id` int(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` longtext NOT NULL,
  `rate` varchar(200) NOT NULL,
  `code` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ib_acc_types`
--

INSERT INTO `ib_acc_types` (`acctype_id`, `name`, `description`, `rate`, `code`) VALUES
(1, 'Savings', '<p>Savings accounts&nbsp;are typically the first official bank account anybody opens. Children may open an account with a parent to begin a pattern of saving. Teenagers open accounts to stash cash earned&nbsp;from a first job&nbsp;or household chores.</p><p>Savings accounts are an excellent place to park&nbsp;emergency cash. Opening a savings account also marks the beginning of your relationship with a financial institution. For example, when joining a credit union, your &ldquo;share&rdquo; or savings account establishes your membership.</p>', '20', 'ACC-CAT-4EZFO'),
(2, ' Retirement', '<p>Retirement accounts&nbsp;offer&nbsp;tax advantages. In very general terms, you get to&nbsp;avoid paying income tax on interest&nbsp;you earn from a savings account or CD each year. But you may have to pay taxes on those earnings at a later date. Still, keeping your money sheltered from taxes may help you over the long term. Most banks offer IRAs (both&nbsp;Traditional IRAs&nbsp;and&nbsp;Roth IRAs), and they may also provide&nbsp;retirement accounts for small businesses</p>', '10', 'ACC-CAT-1QYDV'),
(4, 'Recurring deposit', '<p><strong>Recurring deposit account or RD account</strong> is opened by those who want to save certain amount of money regularly for a certain period of time and earn a higher interest rate.&nbsp;In RD&nbsp;account a&nbsp;fixed amount is deposited&nbsp;every month for a specified period and the total amount is repaid with interest at the end of the particular fixed period.&nbsp;</p><p>The period of deposit is minimum six months and maximum ten years.&nbsp;The interest rates vary&nbsp;for different plans based on the amount one saves and the period of time and also on banks. No withdrawals are allowed from the RD account. However, the bank may allow to close the account before the maturity period.</p><p>These accounts can be opened in single or joint names. Banks are also providing the Nomination facility to the RD account holders.&nbsp;</p>', '15', 'ACC-CAT-VBQLE'),
(5, 'Fixed Deposit Account', '<p>In <strong>Fixed Deposit Account</strong> (also known as <strong>FD Account</strong>), a particular sum of money is deposited in a bank for specific&nbsp;period of time. It&rsquo;s one time deposit and one time take away (withdraw) account.&nbsp;The money deposited in this account can not be withdrawn before the expiry of period.&nbsp;</p><p>However, in case of need,&nbsp; the depositor can ask for closing the fixed deposit prematurely by paying a penalty. The penalty amount varies with banks.</p><p>A high interest rate is paid on fixed deposits. The rate of interest paid for fixed deposit vary according to amount, period and also from bank to bank.</p>', '40', 'ACC-CAT-A86GO'),
(7, 'Current account', '<p><strong>Current account</strong> is mainly for business persons, firms, companies, public enterprises etc and are never used for the purpose of investment or savings.These deposits are the most liquid deposits and there are no limits for number of transactions or the amount of transactions in a day. While, there is no interest paid on amount held in the account, banks charges certain &nbsp;service charges, on such accounts. The current accounts do not have any fixed maturity as these are on continuous basis accounts.</p>', '20', 'ACC-CAT-4O8QW');

-- --------------------------------------------------------

--
-- Table structure for table `ib_admin`
--

CREATE TABLE `ib_admin` (
  `admin_id` int(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `number` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `profile_pic` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ib_admin`
--

INSERT INTO `ib_admin` (`admin_id`, `name`, `email`, `number`, `password`, `profile_pic`) VALUES
(2, 'Rockey Dude', 'rockeydude016@gmail.com', 'iBank-ADM-0516', '123', 'admin-icn.png');

-- --------------------------------------------------------

--
-- Table structure for table `ib_bankaccounts`
--

CREATE TABLE `ib_bankaccounts` (
  `account_id` int(20) NOT NULL,
  `acc_name` varchar(200) NOT NULL,
  `account_number` varchar(200) NOT NULL,
  `acc_type` varchar(200) NOT NULL,
  `acc_rates` varchar(200) NOT NULL,
  `acc_status` varchar(200) NOT NULL,
  `acc_amount` varchar(200) NOT NULL,
  `client_id` varchar(200) NOT NULL,
  `client_name` varchar(200) NOT NULL,
  `client_national_id` varchar(200) NOT NULL,
  `client_phone` varchar(200) NOT NULL,
  `client_number` varchar(200) NOT NULL,
  `client_email` varchar(200) NOT NULL,
  `client_adr` varchar(200) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ib_bankaccounts`
--

INSERT INTO `ib_bankaccounts` (`account_id`, `acc_name`, `account_number`, `acc_type`, `acc_rates`, `acc_status`, `acc_amount`, `client_id`, `client_name`, `client_national_id`, `client_phone`, `client_number`, `client_email`, `client_adr`, `created_at`) VALUES
(19, 'sanju', '097163824', 'Fixed Deposit Account ', '40', 'Active', '0', '10', 'sam', '12012521', '9876543210', 'iBank-CLIENT-3654', 'sanju@mail.com', 'ramanagara', '2023-07-07 17:07:30.536327'),
(20, 'ramya traders', '638910452', 'Current account ', '20', 'Active', '0', '11', 'ramya', '1021320', '002102210', 'iBank-CLIENT-1345', 'ramya@mail.com', 'channapatna', '2023-07-07 17:13:49.413720'),
(21, 'ranjani', '926874035', 'Recurring deposit ', '15', 'Active', '0', '12', 'ranju', '10231021', '012022020', 'iBank-CLIENT-1579', 'ranju@outlook.com', 'dubai', '2023-07-07 17:18:18.464448'),
(22, 'life acc', '913547026', ' Retirement ', '10', 'Active', '0', '13', 'sundar', '1232102', '9876543210', 'iBank-CLIENT-9048', 'abc@look.com', 'kengeri', '2023-07-07 17:20:40.270579'),
(23, 'angle priya', '861503472', 'Savings ', '20', 'Active', '0', '14', 'priya', '1236540', '00210321', 'iBank-CLIENT-2815', 'priya@mail.com', 'Singapore ', '2023-07-07 17:23:51.406906');

-- --------------------------------------------------------

--
-- Table structure for table `ib_clients`
--

CREATE TABLE `ib_clients` (
  `client_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `national_id` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `profile_pic` varchar(200) NOT NULL,
  `client_number` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ib_clients`
--

INSERT INTO `ib_clients` (`client_id`, `name`, `national_id`, `phone`, `address`, `email`, `password`, `profile_pic`, `client_number`) VALUES
(10, 'sam', '12012521', '9876543210', 'ramanagara', 'sanju@mail.com', '123', '', 'iBank-CLIENT-3654'),
(11, 'ramya', '1021320', '002102210', 'channapatna', 'ramya@mail.com', '123', '', 'iBank-CLIENT-1345'),
(12, 'ranju', '10231021', '012022020', 'dubai', 'ranju@outlook.com', '123', '', 'iBank-CLIENT-1579'),
(13, 'sundar', '1232102', '9876543210', 'kengeri', 'abc@look.com', '123', '', 'iBank-CLIENT-9048'),
(14, 'priya', '1236540', '00210321', 'Singapore ', 'priya@mail.com', '123', '', 'iBank-CLIENT-2815');

-- --------------------------------------------------------

--
-- Table structure for table `ib_notifications`
--

CREATE TABLE `ib_notifications` (
  `notification_id` int(20) NOT NULL,
  `notification_details` text NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ib_notifications`
--

INSERT INTO `ib_notifications` (`notification_id`, `notification_details`, `created_at`) VALUES
(29, 'sam Has Deposited $ 1000000 To Bank Account 097163824', '2023-07-07 17:09:40.459537'),
(30, 'sam Has Withdrawn $ 1232 From Bank Account 097163824', '2023-07-07 17:12:28.088691'),
(31, 'ramya Has Deposited $ 1452369 To Bank Account 638910452', '2023-07-07 17:14:00.207622'),
(32, 'ramya Has Deposited $ 123 To Bank Account 638910452', '2023-07-07 17:14:04.513354'),
(33, 'ramya Has Deposited $ 9989 To Bank Account 638910452', '2023-07-07 17:14:08.830151'),
(34, 'ramya Has Deposited $ 4523651 To Bank Account 638910452', '2023-07-07 17:14:14.210670'),
(35, 'ramya Has Withdrawn $ 456123 From Bank Account 638910452', '2023-07-07 17:14:23.475350'),
(36, 'ramya Has Withdrawn $ 1230 From Bank Account 638910452', '2023-07-07 17:14:29.349554'),
(37, 'ramya Has Withdrawn $ 5528000 From Bank Account 638910452', '2023-07-07 17:14:52.281636'),
(38, 'ranju Has Deposited $ 52325 To Bank Account 926874035', '2023-07-07 17:19:17.014544'),
(39, 'sundar Has Deposited $ 10000 To Bank Account 913547026', '2023-07-07 17:21:01.308275'),
(40, 'sundar Has Transfered $ 1232 From Bank Account 913547026 To Bank Account 097163824', '2023-07-07 17:21:36.819456'),
(41, 'sundar Has Transfered $ 123 From Bank Account 913547026 To Bank Account 638910452', '2023-07-07 17:21:47.066888'),
(42, 'priya Has Deposited $ 1203202 To Bank Account 861503472', '2023-07-07 17:24:06.690026'),
(43, 'priya Has Deposited $ 250523 To Bank Account 861503472', '2023-07-07 17:24:11.781456'),
(44, 'priya Has Deposited $ 215151 To Bank Account 861503472', '2023-07-07 17:24:15.391455'),
(45, 'priya Has Deposited $ 2111 To Bank Account 861503472', '2023-07-07 17:24:20.532002'),
(46, 'priya Has Deposited $ 3336 To Bank Account 861503472', '2023-07-07 17:24:24.170188'),
(47, 'priya Has Deposited $ 2233 To Bank Account 861503472', '2023-07-07 17:24:28.506719'),
(48, 'priya Has Withdrawn $ 021221 From Bank Account 861503472', '2023-07-07 17:24:40.205961'),
(49, 'priya Has Withdrawn $ 53697 From Bank Account 861503472', '2023-07-07 17:24:45.059318'),
(50, 'priya Has Transfered $ 123999 From Bank Account 861503472 To Bank Account 638910452', '2023-07-07 17:25:14.538808');

-- --------------------------------------------------------

--
-- Table structure for table `ib_staff`
--

CREATE TABLE `ib_staff` (
  `staff_id` int(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `staff_number` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `sex` varchar(200) NOT NULL,
  `profile_pic` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ib_staff`
--

INSERT INTO `ib_staff` (`staff_id`, `name`, `staff_number`, `phone`, `email`, `password`, `sex`, `profile_pic`) VALUES
(3, 'hacker ', 'iBank-STAFF-6785', '0704975742', 'hacker@gmail.com', '123', 'Male', 'user-profile-min.png');

-- --------------------------------------------------------

--
-- Table structure for table `ib_systemsettings`
--

CREATE TABLE `ib_systemsettings` (
  `id` int(20) NOT NULL,
  `sys_name` longtext NOT NULL,
  `sys_tagline` longtext NOT NULL,
  `sys_logo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ib_systemsettings`
--

INSERT INTO `ib_systemsettings` (`id`, `sys_name`, `sys_tagline`, `sys_logo`) VALUES
(1, 'Internet Banking', 'Financial success at every service we offer.', 'ibankinglg.png');

-- --------------------------------------------------------

--
-- Table structure for table `ib_transactions`
--

CREATE TABLE `ib_transactions` (
  `tr_id` int(20) NOT NULL,
  `tr_code` varchar(200) NOT NULL,
  `account_id` varchar(200) NOT NULL,
  `acc_name` varchar(200) NOT NULL,
  `account_number` varchar(200) NOT NULL,
  `acc_type` varchar(200) NOT NULL,
  `acc_amount` varchar(200) NOT NULL,
  `tr_type` varchar(200) NOT NULL,
  `tr_status` varchar(200) NOT NULL,
  `client_id` varchar(200) NOT NULL,
  `client_name` varchar(200) NOT NULL,
  `client_national_id` varchar(200) NOT NULL,
  `transaction_amt` varchar(200) NOT NULL,
  `client_phone` varchar(200) NOT NULL,
  `receiving_acc_no` varchar(200) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `receiving_acc_name` varchar(200) NOT NULL,
  `receiving_acc_holder` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ib_transactions`
--

INSERT INTO `ib_transactions` (`tr_id`, `tr_code`, `account_id`, `acc_name`, `account_number`, `acc_type`, `acc_amount`, `tr_type`, `tr_status`, `client_id`, `client_name`, `client_national_id`, `transaction_amt`, `client_phone`, `receiving_acc_no`, `created_at`, `receiving_acc_name`, `receiving_acc_holder`) VALUES
(52, 's8aMiCgTPwhQ7Bmy1vIz', '19', 'sanju', '097163824', 'Fixed Deposit Account ', '', 'Deposit', 'Success ', '10', 'sam', '12012521', '1000000', '9876543210', '', '2023-07-07 17:09:40.458088', '', ''),
(53, 'lh89tKQfE3Dv5uqszNYX', '19', 'sanju', '097163824', 'Fixed Deposit Account ', '', 'Withdrawal', 'Success ', '10', 'sam', '12012521', '1232', '9876543210', '', '2023-07-07 17:12:28.087371', '', ''),
(54, 'xPDzFViH7EQCpgn5sr3N', '20', 'ramya traders', '638910452', 'Current account ', '', 'Deposit', 'Success ', '11', 'ramya', '1021320', '1452369', '002102210', '', '2023-07-07 17:14:00.206099', '', ''),
(55, 'wydBgIVe2lvm3j9caRfr', '20', 'ramya traders', '638910452', 'Current account ', '', 'Deposit', 'Success ', '11', 'ramya', '1021320', '123', '002102210', '', '2023-07-07 17:14:04.511821', '', ''),
(56, 'sf5WUmcIVHYEL9zGyQFM', '20', 'ramya traders', '638910452', 'Current account ', '', 'Deposit', 'Success ', '11', 'ramya', '1021320', '9989', '002102210', '', '2023-07-07 17:14:08.828859', '', ''),
(57, 'QdSWejfIXvyEUBCg2xuO', '20', 'ramya traders', '638910452', 'Current account ', '', 'Deposit', 'Success ', '11', 'ramya', '1021320', '4523651', '002102210', '', '2023-07-07 17:14:14.209660', '', ''),
(58, 'UspOP8dwNF2zC3gA4YxH', '20', 'ramya traders', '638910452', 'Current account ', '', 'Withdrawal', 'Success ', '11', 'ramya', '1021320', '456123', '002102210', '', '2023-07-07 17:14:23.474320', '', ''),
(59, 'qbL5z6cIX8T2MGUlWgNx', '20', 'ramya traders', '638910452', 'Current account ', '', 'Withdrawal', 'Success ', '11', 'ramya', '1021320', '1230', '002102210', '', '2023-07-07 17:14:29.348442', '', ''),
(60, 'DwBj96iAJ1pXQ2OmNSan', '20', 'ramya traders', '638910452', 'Current account ', '', 'Withdrawal', 'Success ', '11', 'ramya', '1021320', '5528000', '002102210', '', '2023-07-07 17:14:52.280532', '', ''),
(61, 'X1wQYj7xKRhru9FMpTEH', '21', 'ranjani', '926874035', 'Recurring deposit ', '', 'Deposit', 'Success ', '12', 'ranju', '10231021', '52325', '012022020', '', '2023-07-07 17:19:17.013408', '', ''),
(62, 'p5GcXBWJHYAbO7SQ6Ngs', '22', 'life acc', '913547026', ' Retirement ', '', 'Deposit', 'Success ', '13', 'sundar', '1232102', '10000', '9876543210', '', '2023-07-07 17:21:01.306723', '', ''),
(63, 'V2WHXF5eGkOQqCJpzLMo', '22', 'life acc', '913547026', ' Retirement ', '', 'Transfer', 'Success ', '13', 'sundar', '1232102', '1232', '9876543210', '097163824', '2023-07-07 17:21:36.818163', 'sanju', 'sam'),
(64, 'OTRplbwmox8CNyIZfjrS', '22', 'life acc', '913547026', ' Retirement ', '', 'Transfer', 'Success ', '13', 'sundar', '1232102', '123', '9876543210', '638910452', '2023-07-07 17:21:47.065152', 'ramya traders', 'ramya'),
(65, 'rAnaLS5dCXFb9Ewe6xgt', '23', 'angle priya', '861503472', 'Savings ', '', 'Deposit', 'Success ', '14', 'priya', '1236540', '1203202', '00210321', '', '2023-07-07 17:24:06.688710', '', ''),
(66, 'sWZIRcYwa0XhbDGmBJzN', '23', 'angle priya', '861503472', 'Savings ', '', 'Deposit', 'Success ', '14', 'priya', '1236540', '250523', '00210321', '', '2023-07-07 17:24:11.780215', '', ''),
(67, 'm8YWwPEb2pilg1kFISf4', '23', 'angle priya', '861503472', 'Savings ', '', 'Deposit', 'Success ', '14', 'priya', '1236540', '215151', '00210321', '', '2023-07-07 17:24:15.390321', '', ''),
(68, 'T5BjdEgN4Pec7wDZxHrX', '23', 'angle priya', '861503472', 'Savings ', '', 'Deposit', 'Success ', '14', 'priya', '1236540', '2111', '00210321', '', '2023-07-07 17:24:20.529926', '', ''),
(69, 'EId4fjV6RO0UyqQhnxKX', '23', 'angle priya', '861503472', 'Savings ', '', 'Deposit', 'Success ', '14', 'priya', '1236540', '3336', '00210321', '', '2023-07-07 17:24:24.168935', '', ''),
(71, 'Zx1vgzSfah7mQtMFq9yI', '23', 'angle priya', '861503472', 'Savings ', '', 'Withdrawal', 'Success ', '14', 'priya', '1236540', '021221', '00210321', '', '2023-07-07 17:24:40.205054', '', ''),
(72, 'E4im2KpP7be5GJRqky91', '23', 'angle priya', '861503472', 'Savings ', '', 'Withdrawal', 'Success ', '14', 'priya', '1236540', '53697', '00210321', '', '2023-07-07 17:24:45.058292', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ib_acc_types`
--
ALTER TABLE `ib_acc_types`
  ADD PRIMARY KEY (`acctype_id`);

--
-- Indexes for table `ib_admin`
--
ALTER TABLE `ib_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `ib_bankaccounts`
--
ALTER TABLE `ib_bankaccounts`
  ADD PRIMARY KEY (`account_id`);

--
-- Indexes for table `ib_clients`
--
ALTER TABLE `ib_clients`
  ADD PRIMARY KEY (`client_id`);

--
-- Indexes for table `ib_notifications`
--
ALTER TABLE `ib_notifications`
  ADD PRIMARY KEY (`notification_id`);

--
-- Indexes for table `ib_staff`
--
ALTER TABLE `ib_staff`
  ADD PRIMARY KEY (`staff_id`);

--
-- Indexes for table `ib_systemsettings`
--
ALTER TABLE `ib_systemsettings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ib_transactions`
--
ALTER TABLE `ib_transactions`
  ADD PRIMARY KEY (`tr_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ib_acc_types`
--
ALTER TABLE `ib_acc_types`
  MODIFY `acctype_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `ib_admin`
--
ALTER TABLE `ib_admin`
  MODIFY `admin_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ib_bankaccounts`
--
ALTER TABLE `ib_bankaccounts`
  MODIFY `account_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `ib_clients`
--
ALTER TABLE `ib_clients`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `ib_notifications`
--
ALTER TABLE `ib_notifications`
  MODIFY `notification_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `ib_staff`
--
ALTER TABLE `ib_staff`
  MODIFY `staff_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `ib_systemsettings`
--
ALTER TABLE `ib_systemsettings`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ib_transactions`
--
ALTER TABLE `ib_transactions`
  MODIFY `tr_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
